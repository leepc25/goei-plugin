"""Pack fixed-length joint textures and armless finishing bodies in the existing palette."""
from pathlib import Path
from PIL import Image
import numpy as np
import json
R=Path(__file__).resolve().parent
# The shared connected-component extraction has no file side effects before R=Path.
exec((R/'append_v06_assets.py').read_text(encoding='utf-8').split('R=Path')[0])
meta=json.loads((R/'backup-v06/jyaldi.json').read_text(encoding='utf-8'))
pal=Image.open(R/'backup-v06/jyaldi.png');base=pal.convert('RGBA');frames=[]
def islands(path,count):
    a=np.array(Image.open(path).convert('RGBA'));labels,n,boxes=components(a[:,:,3]>=140)
    sizes=np.bincount(labels.ravel());ids=sorted(range(1,n+1),key=lambda c:sizes[c],reverse=True)[:count]
    ids.sort(key=lambda c:boxes[c-1][0].start+boxes[c-1][0].stop)
    if count==8:ids=sum([sorted(ids[k:k+4],key=lambda c:boxes[c-1][1].start) for k in [0,4]],[])
    else:ids.sort(key=lambda c:boxes[c-1][1].start)
    out=[]
    for cid in ids:
        box=boxes[cid-1];data=a[box].copy();data[:,:,3]=np.where(labels[box]==cid,255,0);out.append(Image.fromarray(data))
    return out
for im,(w,h) in zip(islands(R/'assets/leg-parts-v07-source.png',3),[(17,32),(12,32),(24,9)]):
    im=im.resize((w,h),Image.Resampling.NEAREST);frames.append(dict(image=im,w=w,h=h,ox=0,oy=0,kind='limb',sourceSheet='leg-parts-v07'))
meta['crouchRig']={'thigh':186,'shin':187,'shoe':188,'body':111,'lengths':[32,32]}
meta['finishBodies']=list(range(189,197))
for j,im in enumerate(islands(R/'assets/heavy-body-v07-source.png',8)):
    h=meta['frames'][128+j]['h'];scale=h/im.height;im=im.resize((round(im.width*scale),h),Image.Resampling.NEAREST);a=np.array(im)
    face=(a[:,:,0]>110)&(a[:,:,1]>60)&(a[:,:,0]>a[:,:,1]*1.1)&(a[:,:,0]>a[:,:,2]*1.15)&(a[:,:,3]>100);face[round(h*.3):]=False
    yy,xx=np.where(face);assert len(xx)>3
    eyeX=round(float(np.median(xx)));eyeY=round(float(np.median(yy)))
    frames.append(dict(image=im,w=im.width,h=h,ox=16-eyeX,oy=-h,eyeX=16,eyeY=eyeY-h,sourceSheet='heavy-body-v07'))
canvas=Image.new('RGBA',(1024,base.height+800));canvas.paste(base,(0,0));x,y,rowh=2,base.height+3,0
for f in frames:
    if x+f['w']+2>1024:x,y,rowh=2,y+rowh+3,0
    canvas.paste(f['image'],(x,y));meta['frames'].append({k:v for k,v in f.items() if k!='image'}|dict(x=x,y=y));x+=f['w']+3;rowh=max(rowh,f['h'])
canvas=canvas.crop((0,0,1024,y+rowh+2));q=canvas.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE)
idx=np.array(q);data=np.array(canvas);opaque=(idx==0)&(data[:,:,3]>=140)
if opaque.any():
    values=data[:,:,:3][opaque].astype(np.int32);colors=np.array(pal.getpalette(),dtype=np.int32).reshape(-1,3)[1:64]
    idx[opaque]=((values[:,None,:]-colors[None,:,:])**2).sum(2).argmin(1)+1
idx[data[:,:,3]<140]=0;out=Image.fromarray(idx,'P');out.putpalette(pal.getpalette());out.save(R/'assets/jyaldi.png',optimize=True,transparency=0)
meta['atlasSize']=list(out.size);(R/'assets/jyaldi.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print('Packed',len(frames),'parts and finishing bodies;',len(meta['frames']),'total')
