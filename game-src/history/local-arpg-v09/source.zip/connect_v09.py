from pathlib import Path
import re
R=Path(__file__).resolve().parent
p=R/'src/engine.js';s=p.read_text(encoding='utf-8')
s=re.sub(r'finish:M\([^\n]*?\)', 'finish:M([74,83,84,85,86,87,83,74],[.04,.05,.11,.09,.17,.12,.10,.10])',s,count=1)
s=re.sub(r'hook:M\([^\n]*?\)', 'hook:M([84,85,86,87,83,74],[.12,.04,.18,.12,.08,.10])',s,count=1)
s=s.replace("act==='finish'?107:114","act==='finish'?92:118").replace("act==='finish'?65:90","act==='finish'?94:90")
s=s.replace('Jyaldi ARPG 0.8','Jyaldi ARPG 0.9');p.write_text(s,encoding='utf-8')
for name in ['src/app.js','src/renderer.js','build.py']:
 p=R/name;s=p.read_text(encoding='utf-8').replace('0.8.0','0.9.0').replace('/ 0.8','/ 0.9').replace('강한 훅','전진 강타');p.write_text(s,encoding='utf-8')
p=R/'tests/wholebody.cjs';s=p.read_text(encoding='utf-8').replace("['finish',.29,85]","['finish',.29,86]")
start=s.index("for(const sheet of ['combat-v08'");end=s.index("checks.push('one anatomical",start)
s=s[:start]+'''for(const f of meta.frames.slice(72)){assert(f.headAxis,'missing annotated head '+f.sourceSheet);const h=f.headAxis;assert(Math.abs(Math.hypot(h[2]-h[0],h[3]-h[1])-meta.headAxisTarget)<1.5);assert.equal(f.pelvis[0],10);assert.equal(f.registration,'manually annotated pelvis / support sole');}
'''+s[end:]
s=s.replace('one anatomical import scale per source sheet, no individual pose height normalization','annotated crown/chin axes match canonical size; explicit pelvis replaces guessed image band')
p.write_text(s,encoding='utf-8')
p=R/'tests/regression.cjs';s=p.read_text(encoding='utf-8').replace('poses.indexOf(85)','poses.indexOf(86)');p.write_text(s,encoding='utf-8')
p=R/'tests/browser.cjs';s=p.read_text(encoding='utf-8').replace('===85','===86').replace('pose85','pose86');p.write_text(s,encoding='utf-8')
p=R/'build_v08_review.py';s=p.read_text(encoding='utf-8').replace('잽 → 스트레이트 → 훅','잽 → 스트레이트 → 전진 강타');p.write_text(s,encoding='utf-8')
