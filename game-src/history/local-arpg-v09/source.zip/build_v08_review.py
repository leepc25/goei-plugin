from pathlib import Path
import json,base64
R=Path(__file__).resolve().parent
code='\n'.join((R/f'src/{name}.js').read_text(encoding='utf-8') for name in ['engine','renderer'])
atlas='data:image/png;base64,'+base64.b64encode((R/'assets/jyaldi.png').read_bytes()).decode()
meta=(R/'assets/jyaldi.json').read_text(encoding='utf-8')
html='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>쟈알디 전신 동작 비교</title><style>body{margin:0;background:#141820;color:#ddd;font:16px sans-serif}p{margin:16px}canvas{display:block;width:min(100%,1200px);image-rendering:pixelated}button{padding:8px 20px;margin:8px}</style><p>0.9.0 · 기본 대기 체형 기준 · 전신 작화 비교 / 공격 효과 없이 동작만 재생</p><button id="play">정지 / 재생</button><button id="slow">속도 1× / 0.5×</button><canvas width="1200" height="580"></canvas><script>'''+code+'''
const meta=META,atlas=new Image();let t=0,last=0,paused=false,speed=1;
document.querySelector('#play').onclick=()=>paused=!paused;document.querySelector('#slow').onclick=()=>speed=speed===1?.5:1;
atlas.onload=()=>{const c=document.querySelector('canvas'),g=c.getContext('2d'),r=new JyaldiRenderer(c,atlas,meta);window.JyaldiReview={renderer:r,setTime:value=>{t=value;paused=true;}};
const names=['기본 대기 · 기준 체형','전투 대기','잽 → 스트레이트 → 전진 강타','쪼그리기','걷기','달리기','쪼그려 걷기','하단 발차기'];
const loop=now=>{if(last&&!paused)t+=Math.min(.05,(now-last)/1000)*speed;last=now;g.fillStyle='#1c222d';g.fillRect(0,0,1200,580);
for(let i=0;i<8;i++){const x=(i%4)*300,y=Math.floor(i/4)*290;g.save();g.translate(x,y);g.fillStyle='#b9c3cf';g.font='15px sans-serif';g.fillText(names[i],18,30);g.fillStyle='#4a5564';g.fillRect(10,255,280,1);
let action=['idle','combat','jab','crouch','walk','run','crouch_walk','low_attack'][i],time=t;
if(i===2){const actions=['jab','cross','finish'],total=actions.reduce((s,a)=>s+JyaldiEngine.duration(a),0)+.5;time=t%total;for(const a of actions){action=a;if(time<JyaldiEngine.duration(a))break;time-=JyaldiEngine.duration(a);}if(time>JyaldiEngine.duration('finish')){action='combat';time=0;}}
if(i===7)time=t%(JyaldiEngine.duration(action)+.5);
r.drawSprite({x:140,y:254,z:0,face:1,action,t:time,iframes:0});g.restore();}requestAnimationFrame(loop);};requestAnimationFrame(loop);};atlas.src=ATLAS;
</script></html>'''
html=html.replace('const meta=META','const meta='+meta).replace('atlas.src=ATLAS','atlas.src='+json.dumps(atlas))
(R/'output/Jyaldi_fullbody_review.html').write_text(html,encoding='utf-8')
