from pathlib import Path
import re
R=Path(__file__).resolve().parent
motions={
 'combat':([74,75,74],[.23,.23,.23],True),
 'walk':(list(range(88,96)),.105,True),'run':(list(range(96,104)),.085,True),
 'walk_start':([0,89],[.07,.08],False),'walk_stop':([89,0],[.09,.12],False),
 'run_start':([96,97],[.08,.08],False),'run_stop':([100,74,0],[.10,.09,.10],False),
 'backwalk':(list(range(95,87,-1)),.12,True),'strafe':([89,90,93,94],.14,True),
 'crouch':([106],1.5,True),'crouch_enter':([105,106],[.10,.10],False),'crouch_exit':([105,0],[.10,.10],False),
 'crouch_walk':(list(range(108,116)),.12,True),
 'jab':([76,77,78,79,74],[.07,.05,.14,.12,.08],False),
 'cross':([80,81,82,83,74],[.07,.05,.16,.12,.08],False),
 'finish':([74,84,85,86,87,74],[.09,.20,.15,.14,.14,.10],False),
 'hook':([84,85,86,87,74],[.16,.18,.14,.12,.10],False),
 'low_attack':([106,116,117,118,119,106],[.10,.12,.16,.10,.10,.08],False),
 'guard':([74],1,True),'guard_enter':([73,74],[.07,.08],False),'guard_hit':([75,74],[.09,.10],False),
 'exfil':([96,97,98,99,100,101,102,103],.085,True),
}
p=R/'src/engine.js';s=p.read_text(encoding='utf-8')
for name,(poses,ticks,loop) in motions.items():
 text=name+':M('+str(poses).replace(' ','')+','+str(ticks).replace(' ','')+(',true' if loop else '')+')'
 s,n=re.subn(r'\b'+name+r':M\([^\n]*?\)',text,s,count=1);assert n==1,name
s=s.replace('Jyaldi ARPG 0.2','Jyaldi ARPG 0.8')
p.write_text(s,encoding='utf-8')
