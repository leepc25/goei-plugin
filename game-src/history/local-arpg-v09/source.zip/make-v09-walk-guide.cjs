/* Artist pose reference only. No part of this diagram is used by the game. */
const fs=require('node:fs'),{createCanvas}=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES]}));const c=createCanvas(1600,850),g=c.getContext('2d');
function stroke(a,b,width,color){g.strokeStyle=color;g.lineWidth=width;g.lineCap='round';g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke();}
function foot(phase){const u=((phase%1)+1)%1;if(u<.5)return {x:24-96*u,y:-5};const v=(u-.5)*2;return {x:-24+48*v,y:-5-Math.sin(v*Math.PI)*11};}
function leg(phase,near,hip){const a=foot(phase+(near?0:.5)),dx=a.x-hip.x,dy=a.y-hip.y,d=Math.hypot(dx,dy),b=Math.sqrt(Math.max(0,38*38-d*d/4)),k={x:(hip.x+a.x)/2+dy/d*b,y:(hip.y+a.y)/2-dx/d*b},color=near?'#4f8cde':'#b45d70';stroke(hip,k,15,color);stroke(k,a,11,color);stroke({x:a.x-6,y:a.y+3},{x:a.x+12,y:a.y+3},7,color);}
for(let i=0;i<8;i++){g.save();g.translate(i%4*400+190,Math.floor(i/4)*425+390);g.scale(2,2);const p=i/8,t=p*Math.PI*2,bob=(1-Math.cos(t*2))*1.5,hip={x:Math.sin(t)*2,y:-77+bob},chest={x:-Math.sin(t)*3+2,y:-122+bob};
leg(p,false,{x:hip.x+4,y:hip.y});
function arm(near){const u=-Math.cos(t+(near?0:Math.PI))*.43,s={x:chest.x+(near?-8:8)+Math.sin(t)*(near?4:-4),y:chest.y},e={x:s.x+Math.sin(u)*27,y:s.y+Math.cos(u)*27},h={x:e.x+Math.sin(u+.45)*28,y:e.y+Math.cos(u+.45)*28};stroke(s,e,9,near?'#4f8cde':'#b45d70');stroke(e,h,7,near?'#4f8cde':'#b45d70');}
arm(false);g.fillStyle='#677580';g.beginPath();g.moveTo(chest.x-12,chest.y-7);g.lineTo(chest.x+12,chest.y-7);g.lineTo(hip.x+12,hip.y+5);g.lineTo(hip.x-12,hip.y+5);g.closePath();g.fill();stroke(chest,{x:chest.x+3,y:chest.y-14},9,'#677580');g.fillStyle='#98a4ad';g.beginPath();g.ellipse(chest.x+5,chest.y-24,10,14,0,0,Math.PI*2);g.fill();g.fillRect(chest.x+12,chest.y-27,5,7);
leg(p,true,{x:hip.x-3,y:hip.y});arm(true);g.fillStyle='#fff';g.font='9px sans-serif';g.fillText(String(i+1),-75,12);g.restore();}
fs.writeFileSync('output/Walk_v09_artist_guide.png',c.toBuffer('image/png'));

