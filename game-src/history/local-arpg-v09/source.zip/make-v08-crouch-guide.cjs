/* A drawing reference for alternating support, never a runtime rig. */
const fs=require('node:fs'),{createCanvas}=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES]}));const c=createCanvas(1600,650),g=c.getContext('2d');
function stroke(a,b,w,color){g.strokeStyle=color;g.lineWidth=w;g.lineCap='round';g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke();}
function leg(phase,near,hip){const u=((phase+(near?0:.5))%1+1)%1,s=u<.5,v=(u-.5)*2,a={x:s?14-56*u:-14+28*v,y:-5-(s?0:Math.sin(v*Math.PI)*7)},dx=a.x-hip.x,dy=a.y-hip.y,d=Math.hypot(dx,dy),b=Math.sqrt(Math.max(0,32*32-d*d/4)),k={x:(hip.x+a.x)/2+dy/d*b,y:(hip.y+a.y)/2-dx/d*b},color=near?'#4f8cde':'#b45d70';stroke(hip,k,17,color);stroke(k,a,12,color);stroke({x:a.x-7,y:a.y+3},{x:a.x+12,y:a.y+3},7,color);}
for(let i=0;i<8;i++){g.save();g.translate(i%4*400+185,Math.floor(i/4)*325+295);g.scale(2,2);const p=i/8,t=p*Math.PI*2,bob=Math.sin(t*2),hip={x:Math.cos(t)*2,y:-40+bob};leg(p,false,{x:hip.x+4,y:hip.y});
g.fillStyle='#677580';g.beginPath();g.moveTo(-10,-76+bob);g.lineTo(14,-76+bob);g.lineTo(hip.x+12,hip.y+4);g.lineTo(hip.x-14,hip.y+4);g.closePath();g.fill();stroke({x:7,y:-78+bob},{x:12,y:-83+bob},9,'#677580');g.fillStyle='#98a4ad';g.beginPath();g.ellipse(15,-95+bob,10,14,0,0,Math.PI*2);g.fill();g.fillRect(23,-98+bob,5,7);
stroke({x:13,y:-76+bob},{x:29,y:-59+bob},9,'#b45d70');stroke({x:29,y:-59+bob},{x:32,y:-83+bob},8,'#b45d70');
leg(p,true,{x:hip.x-4,y:hip.y});stroke({x:-8,y:-76+bob},{x:-5,y:-51+bob},10,'#4f8cde');stroke({x:-5,y:-51+bob},{x:18,y:-65+bob},8,'#4f8cde');g.fillStyle='#fff';g.font='9px sans-serif';g.fillText(String(i+1),-75,12);g.restore();}
fs.writeFileSync('output/Crouch_v08_artist_guide.png',c.toBuffer('image/png'));
