"""Build the runtime atlas from original poses and complete canonical-body drawings.

Scale once per sheet from its upright reference. Register to the feet, never to
the face: aligning every head previously erased the torso's weight transfer.
"""
from pathlib import Path
from PIL import Image
import numpy as np
import json,re
R=Path(__file__).resolve().parent
exec((R/'append_v06_assets.py').read_text(encoding='utf-8').split('R=Path')[0])
old=json.loads((R/'backup-v07/jyaldi.json').read_text(encoding='utf-8'))
pal=Image.open(R/'backup-v07/jyaldi.png');atlas=pal.convert('RGBA');meta={k:v for k,v in old.items() if k not in ['frames','armRig','crouchRig','finishBodies','motionMap']};meta['frames']=[]
frames=[];report=[]
for f in old['frames'][:72]:
 im=atlas.crop((f['x'],f['y'],f['x']+f['w'],f['y']+f['h']))
 frames.append({k:v for k,v in f.items() if k not in ['x','y']}|dict(image=im))
for kind,count in [('combat',16),('walk',8),('run',16),('crouch',16),('crouch-walk',8)]:
 source='locomotion' if kind=='run' else kind
 a=np.array(Image.open(R/f'assets/{source}-v08-source.png').convert('RGBA'));labels,n,boxes=components(a[:,:,3]>=140);sizes=np.bincount(labels.ravel())
 ids=sorted(range(1,n+1),key=lambda c:sizes[c],reverse=True)[:count];assert min(sizes[c] for c in ids)>500
 ids.sort(key=lambda c:boxes[c-1][0].start+boxes[c-1][0].stop)
 ids=sum([sorted(ids[k:k+4],key=lambda c:boxes[c-1][1].start) for k in range(0,count,4)],[])
 scale=160/(boxes[ids[0]-1][0].stop-boxes[ids[0]-1][0].start)
 if kind=='crouch-walk':scale=frames[106]['h']/(boxes[ids[0]-1][0].stop-boxes[ids[0]-1][0].start)
 # Running uses the reference walk height in its source; crouch references upright.
 if kind=='run':ids=ids[8:]
 out=[]
 for j,cid in enumerate(ids):
  ys,xs=boxes[cid-1];data=a[ys,xs].copy();data[:,:,3]=np.where(labels[ys,xs]==cid,255,0)
  im=Image.fromarray(data);w,h=round(im.width*scale),round(im.height*scale);im=im.resize((w,h),Image.Resampling.NEAREST);p=np.array(im)
  # A single lowest shoe alternates between feet and causes a huge registration
  # jump. Use the continuous waist/pelvis mass horizontally; floor vertically.
  roots=[]
  for row in p[round(h*.46):round(h*.57),:,3]:
   mask=row>100;edges=np.diff(np.r_[False,mask,False].astype(np.int8));runs=list(zip(np.where(edges==1)[0],np.where(edges==-1)[0]));runs=[(l,r) for l,r in runs if r-l>=max(5,h*.085)]
   if runs:roots.append(sum(runs[-1])/2)
  pelvisX=float(np.median(roots)) if roots else w/2
  rowGround=max(boxes[other-1][0].stop for other in ids[(j//4)*4:(j//4+1)*4]);oy=round((ys.start-rowGround)*scale)
  skin=(p[:,:,0]>110)&(p[:,:,1]>60)&(p[:,:,0]>p[:,:,1]*1.1)&(p[:,:,0]>p[:,:,2]*1.15)&(p[:,:,3]>100);skin[round(h*.35):]=False
  yy,xx=np.where(skin);ox=round(16-pelvisX)
  f=dict(image=im,w=w,h=h,ox=ox,oy=oy,sourceSheet=kind+'-v08',anatomicalScale=scale,registration='pelvis horizontal / floor vertical',wholeBody=True)
  if len(xx):f.update(eyeX=round(float(np.median(xx)))+ox,eyeY=round(float(np.median(yy)))+oy)
  if kind=='crouch-walk':frames[108+j]=f;frame_id=108+j
  else:frames.append(f);frame_id=len(frames)-1
  out.append(dict(id=frame_id,h=h,w=w,ox=ox,oy=oy))
 report.append(dict(sheet=kind,uniformScale=scale,frames=out))
canvas=Image.new('RGBA',(1024,4000));x,y,rowh=2,2,0
for i,f in enumerate(frames):
 if x+f['w']+2>1024:x,y,rowh=2,y+rowh+3,0
 canvas.paste(f['image'],(x,y));meta['frames'].append({k:v for k,v in f.items() if k!='image'}|dict(x=x,y=y));x+=f['w']+3;rowh=max(rowh,f['h'])
canvas=canvas.crop((0,0,1024,y+rowh+2));q=canvas.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE);idx=np.array(q);data=np.array(canvas);opaque=(idx==0)&(data[:,:,3]>=140)
if opaque.any():
 colors=np.array(pal.getpalette(),dtype=np.int32).reshape(-1,3)[1:64];values=data[:,:,:3][opaque].astype(np.int32);idx[opaque]=((values[:,None,:]-colors[None,:,:])**2).sum(2).argmin(1)+1
idx[data[:,:,3]<140]=0
# Preserve every old palette index exactly, especially the user-approved idle.
old_indices=np.array(pal)
for original,f in zip(old['frames'][:72],meta['frames'][:72]):
 idx[f['y']:f['y']+f['h'],f['x']:f['x']+f['w']]=old_indices[original['y']:original['y']+original['h'],original['x']:original['x']+original['w']]
out=Image.fromarray(idx,'P');out.putpalette(pal.getpalette());out.save(R/'assets/jyaldi.png',optimize=True,transparency=0)
meta.update(atlasSize=list(out.size),canonicalPose=0,animationVersion='0.8.0',motionMap=dict(combat=[74,75,74,73],jab=[76,77,78,79,74],cross=[80,81,82,83,74],finish=[74,84,85,86,87,74],walk=list(range(88,96)),run=list(range(96,104)),crouch=[106],crouch_walk=list(range(108,116)),low_attack=[106,116,117,118,119,106]))
(R/'assets/jyaldi.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(R/'output/artwork-v08-registration.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
