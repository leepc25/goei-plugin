"""Import body components, never normalize individual crouched poses by height."""
from pathlib import Path
from PIL import Image
import numpy as np
import json

def components(mask):
    labels=np.zeros(mask.shape,dtype=np.int32)
    height,width=mask.shape
    count=0; boxes=[]
    for sy,sx in zip(*np.where(mask)):
        if labels[sy,sx]:continue
        count+=1; labels[sy,sx]=count
        stack=[(int(sx),int(sy))];left=right=int(sx);top=bottom=int(sy)
        while stack:
            x,y=stack.pop();left=min(left,x);right=max(right,x);top=min(top,y);bottom=max(bottom,y)
            for nx,ny in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
                if 0<=nx<width and 0<=ny<height and mask[ny,nx] and not labels[ny,nx]:
                    labels[ny,nx]=count;stack.append((nx,ny))
        boxes.append((slice(top,bottom+1),slice(left,right+1)))
    return labels,count,boxes

R=Path(__file__).resolve().parent
meta=json.loads((R/'backup-v04/jyaldi.json').read_text(encoding='utf-8'))
pal=Image.open(R/'backup-v04/jyaldi.png')
base=pal.convert('RGBA')
frames=[]
report=[]
for kind,reference,target_height,number in [('heavy',0,meta['frames'][96]['h'],8),('crouch',0,meta['frames'][111]['h'],8),('walk',0,160,8),('run',0,150,8)]:
    source=Image.open(R/f'assets/{kind}-v05-source.png').convert('RGBA')
    a=np.array(source)
    labels,count,boxes=components(a[:,:,3]>=140)
    sizes=np.bincount(labels.ravel())
    ids=sorted(range(1,count+1),key=lambda c:sizes[c],reverse=True)[:number]
    assert len(ids)==number and min(sizes[c] for c in ids)>1500
    ids.sort(key=lambda c:(boxes[c-1][0].start+boxes[c-1][0].stop)/2)
    ordered=[]
    for row in range(number//4):
        ordered+=sorted(ids[row*4:row*4+4],key=lambda c:boxes[c-1][1].start)
    crops=[]
    for cid in ordered:
        box=boxes[cid-1]
        data=a[box].copy()
        data[:,:,3]=np.where(labels[box]==cid,255,0)
        crops.append(Image.fromarray(data))
    scale=target_height/crops[reference].height
    for j,cell in enumerate(crops):
        actual_scale=scale*(crops[0].height/crops[4].height if kind in ['walk','run'] and j>=4 else 1)
        im=cell.resize((round(cell.width*actual_scale),round(cell.height*actual_scale)),Image.Resampling.NEAREST)
        rgb=np.array(im)
        face=(rgb[:,:,0]>110)&(rgb[:,:,1]>60)&(rgb[:,:,0]>rgb[:,:,1]*1.1)&(rgb[:,:,0]>rgb[:,:,2]*1.15)&(rgb[:,:,3]>100)
        face[round(im.height*.27):]=False
        yy,xx=np.where(face)
        assert len(xx)>3, f'Face landmark missing: {kind} {j}'
        faceX,faceY=round(float(np.median(xx))),round(float(np.median(yy)))
        ox,oy=16-faceX,-im.height
        frames.append(dict(image=im,w=im.width,h=im.height,ox=ox,oy=oy,
                           eyeX=16,eyeY=faceY+oy,source=128+len(frames),
                           sourceSheet=kind+'-v05',anatomicalScale=actual_scale,rowCalibration=(actual_scale/scale),
                           faceHeight=int(yy.max()-yy.min()+1)))
    report.append(dict(sheet=kind,scale=scale,heights=[f['h'] for f in frames[-number:]]))
# Register the walk/run head while retaining airborne foot height differences.
for start in [16,24]:
    target=frames[start]['eyeY']
    for i,f in enumerate(frames[start:start+8]):
        y=target+[0,1,0,-1,0,1,0,-1][i]
        f['oy']+=y-f['eyeY']; f['eyeY']=y
canvas=Image.new('RGBA',(1024,base.height+1500));canvas.paste(base,(0,0))
x,y,rowh=2,base.height+3,0
for f in frames:
    if x+f['w']+2>1024:x,y,rowh=2,y+rowh+3,0
    canvas.paste(f['image'],(x,y))
    meta['frames'].append({k:v for k,v in f.items() if k!='image'}|dict(x=x,y=y))
    x+=f['w']+3;rowh=max(rowh,f['h'])
canvas=canvas.crop((0,0,1024,y+rowh+2))
q=canvas.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE)
idx=np.array(q);data=np.array(canvas);opaque=(idx==0)&(data[:,:,3]>=140)
if opaque.any():
    values=data[:,:,:3][opaque].astype(np.int32)
    colors=np.array(pal.getpalette(),dtype=np.int32).reshape(-1,3)[1:64]
    idx[opaque]=((values[:,None,:]-colors[None,:,:])**2).sum(2).argmin(1)+1
idx[data[:,:,3]<140]=0
out=Image.fromarray(idx,'P');out.putpalette(pal.getpalette())
out.save(R/'assets/jyaldi.png',optimize=True,transparency=0)
meta['atlasSize']=list(out.size)
meta['motionMap'].update(finish=list(range(129,136)),crouch_walk=list(range(136,144)),walk=list(range(144,152)),run=list(range(152,160)))
(R/'assets/jyaldi.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(R/'output/artwork-v05-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
