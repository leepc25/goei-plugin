"""Append a generated 4x4 sheet using ONE anatomical scale for every pose."""
from pathlib import Path
from PIL import Image
import numpy as np
import json, sys

ROOT = Path(__file__).resolve().parent
sheet = Image.open(sys.argv[1]).convert('RGBA')
base = Image.open(ROOT/'backup-v021/jyaldi.png').convert('RGBA')
meta = json.loads((ROOT/'backup-v021/jyaldi.json').read_text(encoding='utf-8'))
cells = []
for j in range(16):
    col, row = j % 4, j // 4
    rows = [0,406,753,1009,1245]
    columns = [0,315,650,995,1263] if row == 3 else [0,315,650,970,1263]
    cell = sheet.crop((columns[col],rows[row],columns[col+1],rows[row+1]))
    arr = np.array(cell)
    # Clean only near-transparent generation noise; preserve the supplied alpha.
    arr[arr[:,:,3] < 100] = 0
    cell = Image.fromarray(arr)
    box = cell.getbbox()
    if not box:
        raise ValueError(f'Empty cell {j}')
    cells.append(cell.crop(box))
scale = 160/cells[0].height
canvas = Image.new('RGBA', (1024, base.height+700))
canvas.paste(base, (0, 0))
x, y, rowh = 2, base.height+3, 0
for j, cell in enumerate(cells):
    im = cell.resize((round(cell.width*scale), round(cell.height*scale)), Image.Resampling.NEAREST)
    if x+im.width+2 > canvas.width:
        x, y, rowh = 2, y+rowh+3, 0
    a = np.array(im)
    red = (a[:,:,0].astype(int)-a[:,:,1] > 35) & (a[:,:,0].astype(int)-a[:,:,2] > 25) & (a[:,:,3]>100)
    red[int(im.height*.5):] = False
    ey, ex = np.where(red)
    eye_x = float(np.median(ex)) if len(ex) else im.width*.64
    eye_y = float(np.median(ey)) if len(ey) else 17
    # Register the head horizontally; kicks must extend from the support leg,
    # rather than re-centering the whole bounding box when the leg extends.
    target_x = 13 if j < 4 else 16 if j < 8 else 22
    ox, oy = round(target_x-eye_x), -im.height
    frame = dict(x=x,y=y,w=im.width,h=im.height,ox=ox,oy=oy,
                 eyeX=round(eye_x)+ox,eyeY=round(eye_y)+oy,
                 source=72+j,sourceSheet='motions-v03',anatomicalScale=scale)
    meta['frames'].append(frame)
    canvas.paste(im,(x,y))
    x += im.width+3
    rowh = max(rowh,im.height)
canvas = canvas.crop((0,0,1024,y+rowh+2))
# Reuse the existing common palette, retaining its exact original colors.
pal = Image.open(ROOT/'backup-v021/jyaldi.png')
q = canvas.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE)
indices = np.array(q)
alpha = np.array(canvas)[:,:,3]
opaque_zero = (indices == 0) & (alpha >= 100)
if opaque_zero.any():
    rgb = np.array(canvas)[:,:,:3][opaque_zero].astype(np.int32)
    colors = np.array(pal.getpalette(), dtype=np.int32).reshape(-1,3)[1:64]
    indices[opaque_zero] = ((rgb[:,None,:]-colors[None,:,:])**2).sum(2).argmin(1)+1
indices[alpha < 100] = 0
out = Image.fromarray(indices, 'P')
out.putpalette(pal.getpalette())
out.save(ROOT/'assets/jyaldi.png',optimize=True,transparency=0)
meta['atlasSize'] = list(out.size)
meta['motionMap'].update(idle=list(range(72,76)),combat=list(range(76,80)),
                         crouch_walk=list(range(80,84)),low_attack=list(range(84,88)))
(ROOT/'assets/jyaldi.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print(json.dumps({'scale':scale,'heights':[round(c.height*scale) for c in cells],
                  'atlas':out.size,'poses':len(meta['frames'])}))
