"""Compile generated sprite source sheets into a compact, shared indexed atlas.
No per-tick baking. All source poses are immutable source images.
"""
from PIL import Image
import numpy as np
from scipy.ndimage import label,find_objects
from pathlib import Path
import json,sys,math
ROOT=Path(__file__).resolve().parent
def pack(paths):
    frames=[]
    for sheet,path in enumerate(paths):
        im=Image.open(path).convert('RGBA');count=8 if sheet==4 else 16;rows=count//4;cw,ch=im.width/4,im.height/rows
        mask=np.asarray(im.getchannel('A'))>=140
        component,n=label(mask);sizes=np.bincount(component.ravel());slices=find_objects(component)
        ids=sorted(range(1,n+1),key=lambda i:sizes[i],reverse=True)[:count]
        if len(ids)!=count or min(sizes[i] for i in ids)<1000:raise ValueError('Expected complete sprite components')
        cells={}
        for cid in ids:
            sl=slices[cid-1];b=(sl[1].start,sl[0].start,sl[1].stop,sl[0].stop)
            col=min(3,int((b[0]+b[2])*.5/cw));row=min(rows-1,int((b[1]+b[3])*.5/ch))
            idx=row*4+col
            if idx in cells:raise ValueError('Overlapping sprite assignment')
            cells[idx]=(b,cid)
        # Use one scale per sheet; never stretch a crouching pose into standing height.
        box0=cells[7 if sheet==4 else 0][0];scale=(150 if sheet==2 else 160)/(box0[3]-box0[1])
        for i in range(count):
            globalbox,cid=cells[i];cell=im.crop(globalbox)
            sl=slices[cid-1];alpha=Image.fromarray(np.uint8(component[sl]==cid)*255)
            cell.putalpha(alpha)
            b=alpha.getbbox()
            if not b:raise ValueError('Empty sprite '+str(sheet*16+i))
            src=cell.crop(b)
            w=max(1,round(src.width*scale));h=max(1,round(src.height*scale))
            src=src.resize((w,h),Image.Resampling.NEAREST)
            # Baseline is explicitly stored per pose. All renderer placement uses it.
            # Use original grid's center, not a cropped rectangle's center, to avoid jitter.
            ox=round((b[0]+globalbox[0]-(i%4+.5)*cw)*scale);oy=-h
            arr=np.asarray(cell);red=(arr[:,:,0].astype(int)-arr[:,:,1].astype(int)>40)&(arr[:,:,0].astype(int)-arr[:,:,2].astype(int)>25)&(arr[:,:,1]<110)&(arr[:,:,2]<130)&(arr[:,:,3]>0)
            red[int(cell.height*.48):]=False
            ey,ex=np.where(red);eye={}
            if len(ex):eye={'eyeX':round((float(np.median(ex))+globalbox[0]-(i%4+.5)*cw)*scale),'eyeY':round(float(np.median(ey))*scale)-h}
            frames.append({'image':src,'w':w,'h':h,'ox':ox,'oy':oy,'source':sheet*16+i,**eye})
    # Register the running cycle against the eyes, preserving head size and natural airborne feet.
    if len(frames)>=40:
        ref=frames[32];rx=ref.get('eyeX',35);ry=ref.get('eyeY',-129)
        for j,f in enumerate(frames[32:40]):
            tx=rx;ty=ry+[0,1,0,-1,0,1,0,-1][j]
            f['ox']+=tx-f.get('eyeX',tx);f['oy']+=ty-f.get('eyeY',ty)
            f['eyeX']=tx;f['eyeY']=ty
    # 63 shared opaque colors, one fully transparent palette entry. No dithering.
    swatch=Image.new('RGB',(2048,math.ceil(len(frames)/12)*200),(16,18,27));gpos=0
    for f in frames:
        x=gpos%12*160;y=gpos//12*200
        swatch.paste(f['image'].convert('RGB'),(x,y));gpos+=1
    pal=swatch.quantize(colors=63,method=Image.Quantize.MEDIANCUT)
    colors=pal.getpalette()[:63*3]
    colors=[0,0,0]+colors+[0]*(768-64*3)
    atlas=Image.new('P',(1024,2048),0);atlas.putpalette(colors)
    atlas.info['transparency']=0
    x=y=2;rowh=0;metadata=[None]*len(frames)
    for idx,f in sorted(enumerate(frames),key=lambda v:(-v[1]['h'],-v[1]['w'])):
        if x+f['w']+2>1024:x=2;y+=rowh+3;rowh=0
        if y+f['h']+2>2048:raise ValueError('Atlas overflow')
        # Quantize against original 63 colors; shift indices to reserve transparency.
        q=f['image'].convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE)
        alpha=f['image'].getchannel('A');qdata=bytes((v+1 if a else 0) for v,a in zip(q.tobytes(),alpha.tobytes()))
        q=Image.frombytes('P',q.size,qdata);q.putpalette(colors)
        atlas.paste(q,(x,y))
        metadata[idx]={k:f[k] for k in ['w','h','ox','oy','source','eyeX','eyeY'] if k in f}|{'x':x,'y':y}
        x+=f['w']+3;rowh=max(rowh,f['h'])
    atlas=atlas.crop((0,0,1024,y+rowh+2))
    dest=ROOT/'assets';dest.mkdir(exist_ok=True)
    atlas.save(dest/'jyaldi.png',optimize=True,transparency=0,bits=8)
    data={'name':'Jyaldi','sex':'female','nativeHeight':160,'colors':64,'frames':metadata,'motionMap':{'walk':list(range(16,24)),'run':list(range(32,40))},'characterSpec':{'hair':'long loose straight black','eyes':'red','outfit':'black pantsuit, white shirt, black tie, black gloves'},'atlasSize':list(atlas.size)}
    (dest/'jyaldi.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
    print(json.dumps({'poses':len(frames),'atlas':atlas.size,'pngBytes':(dest/'jyaldi.png').stat().st_size,'decodedBytes':atlas.width*atlas.height*4,'standingHeight':metadata[0]['h']}))
if __name__=='__main__':pack(sys.argv[1:])
